package co.edu.unbosque.model;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.RequestScoped;

@ManagedBean
@SessionScoped
@RequestScoped
public class CalculadoraBean {
	
	    private String usuario;
	    private int num1;
	    private int num2;
	    private int suma;
	    private int resta;
	    private int multiplicacion;
	    private int division;

	    public String getUsuario() {
	        return usuario;
	    }

	    public void setUsuario(String usuario) {
	        this.usuario = usuario;
	    }

	    public int getNum1() {
	        return num1;
	    }

	    public void setNum1(int num1) {
	        this.num1 = num1;
	    }

	    public int getNum2() {
	        return num2;
	    }

	    public void setNum2(int num2) {
	        this.num2 = num2;
	    }

	    public int getSuma() {
	        return suma;
	    }

	    public int getResta() {
	        return resta;
	    }

	    public int getMultiplicacion() {
	        return multiplicacion;
	    }

	    public int getDivision() {
	        return division;
	    }

	    public void calcular() {
	        suma = num1 + num2;
	        resta = num1 - num2;
	        multiplicacion = num1 * num2;
	        division = num1 / num2;
	    }
	}

